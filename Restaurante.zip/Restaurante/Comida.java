package Restaurante;

import java.util.Scanner;

public class Comida {
    Scanner cin = new Scanner(System.in);
    protected boolean consideracionEspecial = false;
    protected double precio;
    protected String nombre;

    public void preguntarConsideracionEspecial() {
        Scanner cin = new Scanner(System.in);
        int respuesta;

        System.out.println("Desea que su comida tenga una consideracion especial?");
        System.out.println("1) Si \tOtro) No");
        System.out.println("(Si esta ordenando comida rapida, sus ingredientes seran vegetarianos.");
        System.out.println("Si ordena alguna comida natural, la porcion sera menor a la habitual)");

        respuesta = cin.nextInt();

        if (respuesta == 1) {
            consideracionEspecial = true;
        } else {
            consideracionEspecial = false;
        }
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}