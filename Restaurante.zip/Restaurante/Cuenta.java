package Restaurante;

import java.util.ArrayList;

public class Cuenta {
    private ArrayList<Orden> listaOrdenes = new ArrayList();
    private double total;

    public ArrayList<Orden> getListaOrdenes() {
        return listaOrdenes;
    }

    public void agregarOrden(Orden objOrden) {
        listaOrdenes.add(objOrden);
    }

    public void calcularTotal() {
        double totalSinIVA = 0.0;
        for (int i = 0; i < listaOrdenes.size(); i++) {
            totalSinIVA += listaOrdenes.get(i).getTotal();
        }
        total = totalSinIVA * 1.16;
    }

    public double getTotal() {
        return total;
    }

}
