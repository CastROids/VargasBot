package Restaurante;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        ArrayList<ComidaRapida> comidaRapida = new ArrayList();
        ArrayList<Cuenta> listaCuentas = new ArrayList();
        Comida comidasDisponibles[] = new Comida[3];

        inicializarComidas(comidasDisponibles);
        ingresarCompras(listaCuentas, comidasDisponibles);
    }

    public static void inicializarComidas(Comida comidas[]) {
        AlimentoNatural carne = new AlimentoNatural();
        AlimentoNatural ensalada = new AlimentoNatural();
        ComidaRapida hamburguesa = new ComidaRapida();

        carne.setNombre("Carne");
        carne.setPrecio(75);
        comidas[0] = carne;

        ensalada.setNombre("Ensalada");
        ensalada.setPrecio(60);
        comidas[1] = ensalada;

        hamburguesa.setNombre("Hamburguesa");
        hamburguesa.setPrecio(40);
        comidas[2] = hamburguesa;
    }

    public static void mostrarMasVendido(ArrayList<Cuenta> listaCuentas) {
        int totalHamburguesa = 0, totalCarne = 0, totalEnsalada = 0;

        for (int i = 0; i < listaCuentas.size(); i++) {
            for (int j = 0; j < listaCuentas.get(i).getListaOrdenes().size(); j++) {
                if (listaCuentas.get(i).getListaOrdenes().get(j).getComida().getNombre() == "Hamburguesa") {
                    totalHamburguesa += listaCuentas.get(i).getListaOrdenes().get(j).getCantidad();
                } else if (listaCuentas.get(i).getListaOrdenes().get(j).getComida().getNombre() == "Carne") {
                    totalCarne += listaCuentas.get(i).getListaOrdenes().get(j).getCantidad();
                } else if (listaCuentas.get(i).getListaOrdenes().get(j).getComida().getNombre() == "Ensalada") {
                    totalEnsalada += listaCuentas.get(i).getListaOrdenes().get(j).getCantidad();
                }
            }
        }

        if (totalCarne > totalEnsalada) {
            if (totalCarne > totalHamburguesa) {
                System.out.println("La comida mas vendida fue la carne");
            } else if (totalHamburguesa > totalCarne) {
                System.out.println("La comida mas vendida fue la hamburguesa");
            } else {
                System.out.println(
                        "La hamburguesa y la carne se fueron las comidas mas vendidas y se vendieron en igual cantidad");
            }
        } else if (totalEnsalada > totalCarne) {
            if (totalEnsalada > totalHamburguesa) {
                System.out.println("La comida mas vendida fue la ensalada");
            } else if (totalHamburguesa > totalEnsalada) {
                System.out.println("La comida mas vendida fue la hamburguesa");
            } else {
                System.out.println(
                        "La hamburguesa y la ensalada se fueron las comidas mas vendidas y se vendieron en igual cantidad");
            }
        } else if (totalCarne > totalHamburguesa) {
            System.out.println(
                    "La carne y la ensalada se fueron las comidas mas vendidas y se vendieron en igual cantidad");
        } else if (totalHamburguesa > totalCarne) {
            System.out.println("La hamburguesa fue la comida mas vendida");
        } else {
            System.out.println("Las tres comidas se vendieron por igual");
        }

    }

    public static void resumirCuenta(Cuenta objCuenta) {
        boolean limon = false, salsa = false, crema = false;

        objCuenta.calcularTotal();

        for (int i = 0; i < objCuenta.getListaOrdenes().size(); i++) {
            Comida objComida = objCuenta.getListaOrdenes().get(i).getComida();

            if (objComida instanceof AlimentoNatural) {
                AlimentoNatural objAlimentoNatural = (AlimentoNatural) objComida;

                System.out.println(objAlimentoNatural.getNombre());

                if (objAlimentoNatural.getComplemento() == "Limon") {
                    limon = true;
                }
                if (objAlimentoNatural.getComplemento() == "Salsa") {
                    salsa = true;
                }
                if (objAlimentoNatural.getComplemento() == "Crema") {
                    crema = true;
                }
            } else {
                ComidaRapida objHamburguesa = (ComidaRapida) objComida;
                
                System.out.println(objHamburguesa.getNombre()+"\t"+objHamburguesa.getTipoComidaRapida());
            }
        }

        System.out.println("Su total sería de $" + objCuenta.getTotal() + " Y lleva los siguientes complementos: ");

        if (limon) {
            System.out.println(" - Limon");
        }
        if (salsa) {
            System.out.println(" - Salsa");
        }
        if (crema) {
            System.out.println(" - Crema");
        }
        
    }

    public static void ingresarCompras(ArrayList<Cuenta> listaCuentas, Comida comidas[]) {
        Scanner cin = new Scanner(System.in);
        int otraCuenta = 1, otraOrden = 1, eleccion, cantidad;
        do {
            Cuenta objCuenta = new Cuenta();
            do {
                Orden objOrden = new Orden();
                System.out
                        .println("¿Que desea ordenar?\n1. Carne\t$75.00\n2. Ensalada\t$60.00\n3. Hamburguesa\t$40.00");
                eleccion = cin.nextInt();
                while (eleccion != 1 && eleccion != 2 && eleccion != 3) {
                    System.out.println("Esa opcion no se encuentra en el menu, intente nuevamente");
                    eleccion = cin.nextInt();
                }
                Comida comidaElegida = comidas[eleccion - 1]; 
             
                if(comidaElegida instanceof AlimentoNatural){
                    AlimentoNatural objAlimentoNatural = new AlimentoNatural();
                    objAlimentoNatural.setNombre(comidaElegida.getNombre());
                    objAlimentoNatural.setPrecio(comidaElegida.getPrecio());

                    objOrden.setComida(objAlimentoNatural);
                }else if(comidaElegida instanceof ComidaRapida){
                    ComidaRapida objComidaRapida = new ComidaRapida();
                    objComidaRapida.setNombre(comidaElegida.getNombre());
                    objComidaRapida.setPrecio(comidaElegida.getPrecio());

                    objOrden.setComida(objComidaRapida);
                }

                System.out.println("Ingrese la cantidad de esa comida que desea comprar: ");
                cantidad = cin.nextInt();
                while (cantidad <= 0) {
                    System.out.println("Ingrese una cantidad valida, por favor");
                    cantidad = cin.nextInt();
                }

                objOrden.setCantidad(cantidad);

                objOrden.getComida().preguntarConsideracionEspecial();

                if (objOrden.getComida() instanceof AlimentoNatural) {
                    AlimentoNatural objAlimentoNatural = (AlimentoNatural) objOrden.getComida();
                    objAlimentoNatural.PreguntarComplemento();
                }

                objOrden.calcularTotal();

                objCuenta.agregarOrden(objOrden);
                System.out.println("Ingrese 0 si ya no hay otra orden para esta cuenta");
                otraOrden = cin.nextInt();

            } while (otraOrden != 0);

            listaCuentas.add(objCuenta);
            resumirCuenta(objCuenta);

            System.out.println("Ingrese 0 si no desea añadir mas cuentas");
            otraCuenta = cin.nextInt();
        } while (otraCuenta != 0);
        mostrarMasVendido(listaCuentas);
    }

}