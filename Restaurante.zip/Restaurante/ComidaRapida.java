package Restaurante;

public class ComidaRapida extends Comida {
    private String tipoComidaRapida;

    public void preguntarConsideracionEspecial() {
        super.preguntarConsideracionEspecial();

        if (consideracionEspecial) {
            System.out.println("Esto significa que su comida sera vegetariana");
        } else {
            System.out.println("Esto significa que su comida sera normal");
        }
        asignarTipo();
    }

    public void cambiarPrecio() {
        if (consideracionEspecial) {
            precio += 25;
        }
    }

    public void asignarTipo() {
        if (consideracionEspecial) {
            this.tipoComidaRapida = "Vegetariana";
            cambiarPrecio();
        } else {
            this.tipoComidaRapida = "Normal";
        }
    }

    public String getTipoComidaRapida() {
        return tipoComidaRapida;
    }

}