package Restaurante;

public class AlimentoNatural extends Comida {
    private String Complemento;

    public void PreguntarComplemento(){
        int respuesta;
        System.out.println("¿Que complemento desea para su comida? \n1. Limon \t2. Salsa \t3. Crema \tOtro. Sin complemento\n");
        respuesta = cin.nextInt();
        switch (respuesta) {
            case 1:
                Complemento = "Limon";
                break;

            case 2:
                Complemento = "Salsa";
                break;
        
            case 3:
                Complemento = "Crema";
                break;
            default:
                Complemento = "";
                break;
        }
    }
    
    public String getComplemento() {
        return Complemento;
    }

}